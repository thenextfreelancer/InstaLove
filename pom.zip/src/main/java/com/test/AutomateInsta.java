package com.test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class AutomateInsta
{
   private WebDriver driver;
   private String baseUrl = "http://localhost:8000/app/index.html";
   
   
   String instaPrefixUrl = "https://www.instagram.com/p/";
   String instaLoginPageUrlKey = "accounts/login";
   String instaSuperGroupName = "My_Group";
   String instaId = "arpitm1989@gmail.com";
   String instaPass = "smita1979";
   
   String telegram_mobile_number = "9540027161";
   
   String loggingDateFormat = "yyyy/MM/dd HH:mm:ss";
   

   @BeforeClass(alwaysRun = true)
   public void setUp() throws Exception
   {
      System.setProperty("webdriver.chrome.driver", "lib/chromedriver.exe");
      driver = new ChromeDriver();
      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
   }

   @Test
   public void test1() throws Exception
   {
      driver.get(baseUrl);
      driver.manage().window().maximize();
      
      Thread.sleep(10000);
      driver.findElement(By.name("phone_number")).sendKeys(telegram_mobile_number);
      Thread.sleep(5000);
      driver.findElement(By.className("login_head_submit_btn")).click();

      Thread.sleep(5000);
      driver.findElement(By.className("btn-md-primary")).click();
      Thread.sleep(30000);

      List<WebElement> els = driver.findElements(By.className("im_dialog_peer")); //list of groups in telegram
      WebElement grp = null;
      for (WebElement el : els)
      {
         if (el.getText().equals(instaSuperGroupName))
         {
            grp = el;
            break;
         }
      }

      if (grp != null)
      {
         grp.click();  //mentioned group selected
      }

      int timePeriodInMinutes = 60, intervalInMinutes = 1, time = 0;

      Set<String> clicked = new HashSet<String>();  // Set of links which are clicked
      
      //Loop will check for the new links every minute(default) and run liking algorithm
      while (time < (timePeriodInMinutes * 60000))
      {
         
         DateFormat dateFormat = new SimpleDateFormat(loggingDateFormat);
         Date date = new Date();
         if(time == 0) {
            System.out.println("########################################## LOG Message ################################## "); 
            System.out.println("Starting to analyse instagram message links for first time on: "+dateFormat.format(date));  
            System.out.println("########################################## LOG Message ################################## "); 
         }
         else {
            System.out.println("########################################## LOG Message ################################## "); 
            System.out.println("Starting to analyse instagram message links on: "+dateFormat.format(date));
            System.out.println("########################################## LOG Message ################################## "); 
         }
            
         List<WebElement> matches = driver.findElements(By.tagName("a"));
         Set<String> instaLinks = new HashSet<String>();

         for (WebElement match : matches)
         {
            String clink = match.getText();
            if (clink.startsWith(instaPrefixUrl))
            {
               boolean doAdd = true;
               for (Iterator<String> it = clicked.iterator(); it.hasNext();)
               {
                  String link = it.next();
                  if (link.equals(clink)) {
                     doAdd = false;
                     break;
                  }
               }

               if (doAdd) {
                  instaLinks.add(clink);
               }
                  
            }

         }

         //Starting opening the Insta inks and liking it!
         for (String instaLink : instaLinks)
         {
            driver.findElement(By.linkText(instaLink)).click();
            Thread.sleep(2000);
            List<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(tabs2.get(1));
            By heartButton = By.cssSelector("span._8scx2.coreSpriteHeartOpen");
            boolean isHeartPresent = isElementPresent(heartButton);
            if(isHeartPresent) {
               driver.findElement(heartButton).click();
            } else {
               // move on. I assume it is already liked! .. logging a message
               System.out.println("########################################## LOG Message ################################## "); 
               System.out.println("The post on insta: "+instaLink+" is already liked!");
               System.out.println("########################################## LOG Message ################################## "); 
            }
            clicked.add(instaLink);
            String previousURL = driver.getCurrentUrl();

            if (previousURL.contains(instaLoginPageUrlKey))
            {
               // Need login in Instagram
               driver.findElement(By.name("username")).sendKeys(instaId);
               driver.findElement(By.name("password")).sendKeys(instaPass);
               WebElement wb = driver.findElement(By.cssSelector("span[id=react-root]"));
               wb.findElement(By.tagName("button")).click();
               clicked.add(instaLink);
               
               if(isHeartPresent) {
                  driver.findElement(heartButton).click();
               } else {
                  // move on. I assume it is already liked!.. logging a message
                  System.out.println("########################################## LOG Message ################################## "); 
                  System.out.println("The post on insta: "+instaLink+" is already liked!");
                  System.out.println("########################################## LOG Message ################################## "); 
               }
               
            }
            Thread.sleep(2000);

            driver.close();

            Thread.sleep(2000);

            driver.switchTo().window(tabs2.get(0));
         }
         time = 60000 * intervalInMinutes;
         Thread.sleep(time);
      }
      
      System.out.println("########################################## LOG Message ################################## "); 
      System.out.println("Following links are clicked and hopefully liked by the software!!");
      for (Iterator<String> it = clicked.iterator(); it.hasNext();)
      {
         String link = it.next();
         System.out.println("Insta Links: "+link);
      }
      System.out.println("########################################## LOG Message ################################## "); 
   }

   @AfterClass(alwaysRun = true)
   public void tearDown() throws Exception
   {
      driver.quit();
   }
   
   private boolean isElementPresent(By by) {
      try {
        driver.findElement(by);
        return true;
      } catch (NoSuchElementException e) {
        return false;
      }
    }

}
